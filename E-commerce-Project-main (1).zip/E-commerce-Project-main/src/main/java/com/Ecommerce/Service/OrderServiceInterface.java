package com.Ecommerce.Service;

import com.Ecommerce.Entity.User;

public interface OrderServiceInterface {
	
	public void generateOrderId(User user);
    
}
