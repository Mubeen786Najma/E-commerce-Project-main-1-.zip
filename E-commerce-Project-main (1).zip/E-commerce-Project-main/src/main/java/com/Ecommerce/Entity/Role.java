package com.Ecommerce.Entity;

public enum Role {
	
	USER,
	
	ADMIN

}
